ALL ROUNDER RIDE – ANDROID APK PROJECT
======================================

Is ZIP mein aapki di hui HTML app ko Android WebView app ke roop mein pack kiya gaya hai.

ABHI KYA CHALTA HAI
-------------------
- Aapki original HTML screen aur uske demo features Android app ke andar khulte hain.
- Customer registration, sample cars, sample bus/traveller, booking history aur owner demo dashboard HTML mein maujood hain.
- Payment screen DEMO hai: asli paisa charge nahi hota.
- Tracking screen DEMO animation hai: asli GPS location nahi dikhati.
- Sample drivers/vehicles aur owner PIN demo data hain.

PUBLIC DOWNLOAD LINK BANANE KE LIYE (FREE GITHUB RELEASE)
---------------------------------------------------------
1. github.com par apna free account banayein / sign in karein.
2. New repository banayein. Naam: AllRounderRide. Repository ko Public rakhein.
3. Is ZIP ko laptop par Extract karein.
4. Extract hue AllRounderRide-Android folder ke ANDAR ki sab files/folders repository mein upload karein.
   Dhyan: repository ke root par app, .github, build.gradle, settings.gradle hone chahiye.
5. GitHub mein Add file > Upload files se files upload karke Commit changes karein.
6. Repository ke Actions tab mein jaakar workflow enable karein agar GitHub kahe.
7. APK build test karne ke liye Actions > Build and publish All Rounder Ride APK > Run workflow chala sakte hain.
   Isse APK Actions ke Artifacts mein milega; artifact login ke baad download hota hai aur 30 din rahega.
8. Sabko bhejne layak permanent-style public download link banane ke liye repository ke Releases section mein tag banayein:
   v1.0.0
   Tag push/create karte hi workflow APK build karke Release asset ke roop mein app-debug.apk attach karega.
9. Public repository/release ka direct link is format mein hoga:
   https://github.com/ YOUR-USERNAME /AllRounderRide/releases/latest/download/app-debug.apk
   YOUR-USERNAME ko apne GitHub username se replace karein.

ANDROID STUDIO SE LOCAL BUILD
-----------------------------
1. Android Studio install karein.
2. Extract kiya hua AllRounderRide-Android folder Open karein.
3. Gradle Sync hone dein; Android SDK Platform 35 aur Java 17 use honge.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. APK yahan milega: app/build/outputs/apk/debug/app-debug.apk

IMPORTANT – PUBLIC LAUNCH SE PEHLE
---------------------------------
Yeh abhi HTML demo ka Android wrapper hai, complete production booking platform nahi.
Public users ki real booking, owner accounts, server/database, OTP, secure admin login,
real payment gateway, real-time GPS, notifications, privacy policy aur customer support
ke liye backend aur service integrations alag se develop/configure karne honge.
Demo app ko asli payment ya live tracking app ke roop mein advertise na karein.

Debug APK testing ke liye hai. Wide public distribution ke liye release signing key aur
signed release APK banana behtar hai. Signing key ko GitHub par kabhi upload na karein.
